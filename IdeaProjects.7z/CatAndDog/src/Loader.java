public class Loader {
    public static void main(String[] args) {
        int i = 45;
        while (i < 350) {
        i++;
    }

        System.out.println("Value i = " + i);
}
}
