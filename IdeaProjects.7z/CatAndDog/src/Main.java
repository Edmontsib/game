import java.util.*;

public class Main {

    public static void main(String[] args) {
        Map<Integer, Integer> map = new HashMap<>(); // строка 1
        for (int i = 1; i <= 10; i++) {
            map.put(i, i * i); // строка 2
        }
        System.out.println(map.get(4)); // строка 3
    }
}